# Adou — Fè APK

Pwojè sa a mete paj Adou a nan yon aplikasyon Android WebView, san chanje HTML/CSS yo.

## Metòd ki pi fasil sou telefòn
1. Kreye yon kont GitHub epi yon nouvo repository ki rele `adou-apk`.
2. Upload tout fichye ak dosye ki nan pwojè sa a.
3. Ale nan **Actions** > **Build APK** > **Run workflow**.
4. Lè li fini, ouvri rezilta **Adou-debug-apk** epi telechaje `app-debug.apk`.
5. Sou Android, aktive enstalasyon aplikasyon ki soti nan sous ou otorize a, epi enstale APK a.

## Metòd òdinatè
Ouvri pwojè a nan Android Studio, tann Gradle fini, epi chwazi:
Build > Build Bundle(s) / APK(s) > Build APK(s)

APK a ap soti nan:
`app/build/outputs/apk/debug/app-debug.apk`
